# ================================
# DATA CLASSIFICATION USING AI
# Internship Project 2
# ================================

# Import Libraries
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
import pandas as pd

# Load Dataset
iris = load_iris()

# Convert dataset into DataFrame
data = pd.DataFrame(
    iris.data,
    columns=iris.feature_names
)

# Add target column
data['target'] = iris.target

print("===== DATASET SAMPLE =====")
print(data.head())

# Features and Labels
X = iris.data
y = iris.target

# Split Data into Training and Testing
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Create Model
model = KNeighborsClassifier(n_neighbors=3)

# Train Model
model.fit(X_train, y_train)

# Predict Test Data
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)

print("\n===== MODEL ACCURACY =====")
print(f"Accuracy: {accuracy * 100:.2f}%")

# Classification Report
print("\n===== CLASSIFICATION REPORT =====")
print(classification_report(y_test, y_pred))

# Predict New Flower
sample = [[5.1, 3.5, 1.4, 0.2]]

prediction = model.predict(sample)

print("\n===== NEW PREDICTION =====")

flower_names = iris.target_names

print("Predicted Flower:", flower_names[prediction][0])